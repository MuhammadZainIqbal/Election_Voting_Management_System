A simple and basic Election Voting Management System project that my project mates and I made in second semester of BS computer science in C++ using simple CLI
